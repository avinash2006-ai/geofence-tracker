// Geo-Fence Tracker server — no npm install needed (Node 16+)
// Run:  node server.js     Admin: http://localhost:3000/admin?key=admin123
const http = require('http'), fs = require('fs'), path = require('path');
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'admin123';

let fence = null;            // {lat, lng, radius}
const students = {};         // id -> {id,name,lat,lng,acc,inside,time,trail:[]}
const clients = [];
const log = [];              // in/out events {name,type,time}          // SSE connections (admin)

const dist = (a, b, c, d) => { // haversine, metres
  const R = 6371000, t = x => x * Math.PI / 180;
  const h = Math.sin(t(c - a) / 2) ** 2 + Math.cos(t(a)) * Math.cos(t(c)) * Math.sin(t(d - b) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
};
const broadcast = () => {
  const msg = `data: ${JSON.stringify({ fence, log: log.slice(-100), students: Object.values(students) })}\n\n`;
  clients.forEach(c => c.write(msg));
};
const body = req => new Promise(r => {
  let s = ''; req.on('data', d => { s += d; if (s.length > 1e5) req.destroy(); });
  req.on('end', () => { try { r(JSON.parse(s || '{}')); } catch { r({}); } });
});
const file = (res, f) => fs.readFile(path.join(__dirname, 'public', f), (e, d) => {
  if (e) { res.writeHead(404); return res.end('Not found'); }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(d);
});

http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  const isAdmin = u.searchParams.get('key') === ADMIN_KEY;

  if (p === '/' || p === '/join') return file(res, 'join.html');
  if (p === '/admin') return isAdmin ? file(res, 'admin.html') : (res.writeHead(401), res.end('Wrong or missing key'));

  if (p === '/api/location' && req.method === 'POST') {
    const b = await body(req);
    if (!b.id || typeof b.lat !== 'number' || typeof b.lng !== 'number') { res.writeHead(400); return res.end(); }
    const s = students[b.id] || (students[b.id] = { id: b.id, trail: [] });
    if (!s.custom) s.name = String(b.name || 'Student').slice(0, 40);
    const prev = s.inside;
    s.lat = b.lat; s.lng = b.lng; s.acc = b.acc || 0; s.time = Date.now();
    s.inside = fence ? dist(fence.lat, fence.lng, b.lat, b.lng) <= fence.radius : null;
    if (prev !== undefined && prev !== null && prev !== s.inside) log.push({ name: s.name, type: s.inside ? 'ENTERED' : 'LEFT', time: Date.now() });
    else if (prev === undefined && s.inside !== null) log.push({ name: s.name, type: s.inside ? 'ENTERED' : 'LEFT', time: Date.now() });
    s.trail.push([b.lat, b.lng]); if (s.trail.length > 300) s.trail.shift();
    broadcast(); res.writeHead(200); return res.end('ok');
  }

  if (p.startsWith('/api/') && !isAdmin) { res.writeHead(401); return res.end(); }

  if (p === '/api/fence' && req.method === 'POST') {
    const b = await body(req);
    if (typeof b.lat === 'number' && typeof b.lng === 'number' && b.radius > 0) {
      fence = { lat: b.lat, lng: b.lng, radius: b.radius };
      Object.values(students).forEach(s => s.inside = dist(fence.lat, fence.lng, s.lat, s.lng) <= fence.radius);
      broadcast();
    }
    res.writeHead(200); return res.end('ok');
  }
  if (p === '/api/rename' && req.method === 'POST') {
    const b = await body(req);
    if (students[b.id] && b.name) { students[b.id].name = String(b.name).slice(0, 40); students[b.id].custom = true; broadcast(); }
    res.writeHead(200); return res.end('ok');
  }
  if (p === '/api/clear' && req.method === 'POST') {
    Object.keys(students).forEach(k => delete students[k]); log.length = 0; broadcast(); res.writeHead(200); return res.end('ok');
  }
  if (p === '/api/stream') {
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    clients.push(res);
    res.write(`data: ${JSON.stringify({ fence, log: log.slice(-100), students: Object.values(students) })}\n\n`);
    const ka = setInterval(() => res.write(': ping\n\n'), 20000);
    req.on('close', () => { clearInterval(ka); clients.splice(clients.indexOf(res), 1); });
    return;
  }
  res.writeHead(404); res.end('Not found');
}).listen(PORT, () => console.log(`Admin:   http://localhost:${PORT}/admin?key=${ADMIN_KEY}\nStudent: http://localhost:${PORT}/join`));
